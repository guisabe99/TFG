library(openxlsx)
library(ggplot2)
library(dplyr)
library(rlang)

# Leer datos
datos<-read.xlsx("C:/Users/VORPC/Desktop/Nueva carpeta/Universidad/TFG/TFG/Datos.xlsx")
datos<-datos[2661:3040,]
datos <- datos[ , -c(1,2,3)]

# Convertir columnas a factores
datos$Ganador_Final <- as.factor(datos$Ganador_Final)
datos$Sistema_L <- as.factor(datos$Sistema_L)
datos$Sistema_V <- as.factor(datos$Sistema_V)

# Solicitar nombres de variables al usuario
x_var <- readline(prompt = "Introduce el nombre de la variable para el eje X (gráfico de barras): ")
y_var <- readline(prompt = "Introduce el nombre de la variable para el 'fill' (gráfico de barras): ")

# Gráfico de barras
ggplot(datos, aes_string(x = x_var, fill = y_var)) + 
  geom_bar() + 
  xlab(x_var) + 
  ylab("Frecuencia") + 
  ggtitle("Gráfico de Barras") +
  labs(fill = y_var) +
  theme_minimal()

# Solicitar nuevas variables para el histograma (opcional, pueden ser las mismas)
x_hist_var <- readline(prompt = "Introduce el nombre de la variable para el eje X (histograma): ")
fill_hist_var <- readline(prompt = "Introduce el nombre de la variable para el 'fill' (histograma): ")

# Histograma
ggplot(datos, aes_string(x = x_hist_var, fill = fill_hist_var)) + 
  geom_histogram(bins = 50, position = "identity", alpha = 0.6) + 
  xlab(x_hist_var) + 
  ylab("Frecuencia") + 
  ggtitle("Histograma") +
  theme_minimal()

# Agregar variable "temporada" manualmente (suponiendo que hay igual número de filas por temporada)
datos$temporada <- rep(c("2016-17", "2017-18", "2018-19", "2019-20", 
                         "2020-21", "2021-22", "2022-23", "2023-24", "2024-25"), 
                       each = nrow(datos)/9)

# Solicitar variable al usuario
y_disp_var <- readline(prompt = "Introduce el nombre de la variable para el eje Y (gráfico de dispersión): ")

# Calcular promedios por temporada usando tidy evaluation
promedios <- datos %>%
  group_by(temporada) %>%
  summarise(valor_promedio = mean(!!sym(y_disp_var), na.rm = TRUE))

# Crear gráfico de dispersión
ggplot(promedios, aes(x = temporada, y = valor_promedio, group = 1)) +
  geom_point(color = "blue", size = 3) +
  geom_line(color = "red", size = 1) +
  labs(
    title = paste("Evolución del Promedio de", y_disp_var, "por Temporada"),
    x = "Temporada",
    y = paste("Promedio de", y_disp_var)
  ) +
  theme_minimal()
